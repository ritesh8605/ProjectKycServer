package com.app.entities;

public enum UserType {
	VOTER,CANDIDATE,ADMIN,EXUSER
}
